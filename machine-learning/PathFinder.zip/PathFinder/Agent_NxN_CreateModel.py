import pandas as pd

dataset = pd.read_csv("Agent_5x5_TrainData.csv", sep=";")

print("\nDataset:")
print(dataset.head(10))

#Drop Id Column
dataset.drop('Simulation', axis = 1, inplace=True)

#Split X and Y
X = dataset.drop('Reward',axis=1)
Y = dataset['Reward']

#One hot encoding for Action column
from sklearn.preprocessing import OneHotEncoder
enc = OneHotEncoder(handle_unknown='ignore')
enc_df = pd.DataFrame(enc.fit_transform(X[['Action']]).toarray())
X = X.join(enc_df)
X = X.drop(['Action'],axis=1)

print("\nDataset (after one hot encoding):")
print(X.head(10))

#Regresion Neural Network Model
from sklearn.neural_network import MLPRegressor
regressor = MLPRegressor(hidden_layer_sizes = (100, 75, 50, 25), activation = 'relu', solver = 'sgd', learning_rate = 'adaptive', max_iter = 500)
regressor.fit(X, Y)
print(regressor.loss_)

#Save Model
import pickle
save_nn = open("Agent_5x5_TrainedModel", "wb")
pickle.dump(regressor, save_nn)
save_nn.close()

