from sklearn.neural_network import MLPRegressor
import pickle
import numpy as np

#UP: 0 0 0 1
#DOWN: 1 0 0 0 
#LEFT: 0 1 0 0
#RIGHT: 0 0 1 0

def simulate(Id, CurrentR, CurrentC, TargetR, TargetC, MaxR, MaxC):
  regressor_file = open("Agent_5x5_TrainedModel", "rb")
  regressor = pickle.load(regressor_file) 
  regressor_file.close()

  while CurrentR != TargetR or CurrentC != TargetC:

    UP_NN = np.array([CurrentR,CurrentC,TargetR,TargetC,0,0,0,1]).reshape(1,-1)
    DOWN_NN = np.array([CurrentR,CurrentC,TargetR,TargetC,1,0,0,0]).reshape(1,-1)
    LEFT_NN = np.array([CurrentR,CurrentC,TargetR,TargetC,0,1,0,0]).reshape(1,-1)
    RIGHT_NN = np.array([CurrentR,CurrentC,TargetR,TargetC,0,0,1,0]).reshape(1,-1)

    pred_rew = regressor.predict(UP_NN)
    Move = "UP"
    tmp = regressor.predict(DOWN_NN)
    if tmp > pred_rew:
      pred_rew = tmp
      Move = "DOWN"
    tmp = regressor.predict(LEFT_NN)
    if tmp > pred_rew:
      pred_rew = tmp
      Move = "LEFT"
    tmp = regressor.predict(RIGHT_NN)
    if tmp > pred_rew:
      pred_rew = tmp
      Move = "RIGHT"

    print(Id + "," + str(CurrentR) + "," + str(CurrentC) + "," + str(TargetR) + "," + str(TargetC) + "," + Move + "," + str(pred_rew[0]))

    if Move == "UP":
      CurrentR = CurrentR - 1
      if CurrentR < 1:
        CurrentR = MaxR
    elif Move == "DOWN":
      CurrentR = CurrentR + 1
      if CurrentR > MaxR:
        CurrentR = 1
    elif Move == "RIGHT":
      CurrentC = CurrentC + 1
      if CurrentC > MaxC:
        CurrentC = 1
    else:
      CurrentC = CurrentC - 1
      if CurrentC < 1:
        CurrentC = MaxC
    #print("Current: " + str(CurrentR) + "," + str(CurrentC))
  print(Id + "," + str(TargetR) + "," + str(TargetC) + "," + str(TargetR) + "," + str(TargetC) + "," + "END" + "," + str(1000))
	
def test():
  for i in range(5):
    MaxR = 5
    MaxC = 5
    
    CurrentR = np.random.randint(low=1, high=MaxR, size=1)[0]
    CurrentC = np.random.randint(low=1, high=MaxC, size=1)[0]
    TargetR = np.random.randint(low=1, high=MaxR, size=1)[0]
    TargetC = np.random.randint(low=1, high=MaxC, size=1)[0]
    '''
    CurrentR = 3
    CurrentC = 1
    TargetR = 4
    TargetC = 4
	'''
    print("S" + str(i) + "," + str(CurrentR) + "," + str(CurrentC)+ "," + str(TargetR) + "," + str(TargetC) + "," + "NONE" + "," + "-999")
    simulate("S" + str(i), CurrentR, CurrentC, TargetR, TargetC, MaxR, MaxC)

test()
