package geneticos;

import java.util.Random;

/**
 * Representa la clase principal del Algoritmo
 * GenÃ©tico Simple con Modificaciones
 * para resolver el Problema del Agente Viajero
 */
public class AGETSP 
{
    /**
     * Entrada principal del AGE
     * @param args 
     */
    public static void main(String[] args) 
    {
        GeneticAlgorithm.rutaArchivoCiudades = "p01_d.txt";
        run();
    }
    
    public static void run()
    {
        
        Fitness.init();
        //23898932
        GeneticAlgorithm.rnd = new Random(23898932);
        Poblacion pob = new Poblacion(GeneticAlgorithm.tamPoblacion, true);
        Genotipo mejor = pob.getFittest();
        int contadorGen;
        int numGen = 1;
        
        for( contadorGen = 1; contadorGen <= GeneticAlgorithm.numGeneraciones; contadorGen++ ) {
            pob = GeneticAlgorithm.evoluciona(pob, mejor.getCopia());
            if(pob.getFittest().getFitness() < mejor.getFitness()) {
                mejor = pob.getFittest().getCopia();
                numGen = contadorGen;
            }
            System.out.println("Generación: " +contadorGen +"; Fitness del fittest: " +pob.getFittest().getFitness());
        }
        int [] var = mejor.getArreglo();
        System.out.println("Mejor Generación: " + numGen  +"; Fitness del mejor Camino: " +mejor.getFitness());
        for(int i: var)
            System.out.print(i + " ");
        System.out.println();
                
    }
}

