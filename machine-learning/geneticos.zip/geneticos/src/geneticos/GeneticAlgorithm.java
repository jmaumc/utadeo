package geneticos;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.Random;

public class GeneticAlgorithm 
{
    /**
     * Probabilidad de cruzamiento
     */
    public static double tasaCruzamiento = 1;

    /**
     * Probabilidad de mutaciÃ³n
     */
    public static double tasaMutacion = 0.03;
    
    /**
     * Indica si se debe guardar el mejor individuo en
     * la nueva poblacion
     */
    private static boolean elitismo = true;
    
    /**
     * El nÃºmero de ciudades que procesa el algoritmo
     */
    public static int numCiudades = 15;
    
    /**
     * NÃºmero de individuos que tendrÃ¡ cada generaciÃ³n
     */
    public static int tamPoblacion = 100;
    
    /**
     * NÃºmero de iteraciones (generaciones) que fabricarÃ¡
     * el Algoritmo GenÃ©tico Simple con Modificaciones
     */
    public static int numGeneraciones = 10000;
    
    /**
     * Ruta del archivo de donde se encuentran la 
     * matriz de ciudades
     */
    public static String rutaArchivoCiudades = "input";
    
    /**
     * Objeto auxiliar para controlar la generaciÃ³n de nÃºmeros
     * aleatorios
     */
    public static Random rnd;
    
    /**
     * Obtiene una nueva poblaciÃ³n aplicando los pasos del 
     * Algoritmo GenÃ©tico Simple con Modificaciones
     * @param pob La poblaciÃ³n Inicial
     * @param mejor El mejor individuo
     * @return Una nueva poblaciÃ³n evolucionada 
     * Genotype 
     */
    public static Poblacion evoluciona(Poblacion pob, Genotipo mejor)
    {
        Poblacion nuevaPob = new Poblacion(pob.size(), false);
        if (elitismo) {
            //nuevaPob.guardarIndividuo(0, pob.getFittest().getCopia());
            nuevaPob.insertaOrdenado(mejor.getCopia());
        }
        int offsetElitismo;
        if(elitismo)
            offsetElitismo = 1;
        else
            offsetElitismo = 0;
        double[] dist = pob.linealRanking();
        for (int i = offsetElitismo; i < pob.size(); i++) {
            Genotipo A = pob.ruleta(dist);
            Genotipo B = pob.ruleta(dist);
            if(GeneticAlgorithm.rnd.nextDouble() <= tasaCruzamiento) {
                nuevaPob.insertaOrdenado(crossover(A, B));
                //nuevaPob.guardarIndividuo(i, crossover(A, B));
            }
            else
                nuevaPob.insertaOrdenado(pob.getGenotipo(i));
                //nuevaPob.guardarIndividuo(i, pob.getGenotipo(i));
        }
        nuevaPob.pegaArreglo();
        for(int i = 0; i < nuevaPob.size(); i++) {
            mutacion(nuevaPob.getGenotipo(i));
        }
        return nuevaPob;
        
    }
    
    /**
     * Muta los genes de un individuo
     * @param gen El individuo a mutar
     */
    private static void mutacion(Genotipo gen)
    {
        int primero, segundo;
        
        if(GeneticAlgorithm.rnd.nextDouble() <= tasaMutacion) {
            primero = 0;
            segundo = 0;
            while(primero==segundo) {
                primero = (int)(GeneticAlgorithm.rnd.nextDouble()*numCiudades);
                segundo = (int)(GeneticAlgorithm.rnd.nextDouble()*numCiudades);
            }
            int var = gen.getGen(primero);
            gen.setGen(primero,gen.getGen(segundo));
            gen.setGen(segundo, var);
        }
    }
    
    /**
     * Crea un individuo por medio del cruzamiendo OX de
     * otros dos individuos
     * @param A El padre
     * @param B El padre
     * @return Un nuevo Genotipo con el resultado del
     * cruzamiento
     */
    private static Genotipo crossover(Genotipo A, Genotipo B)
    {
        Genotipo hijo = new Genotipo();
        int lugar1 = 0, lugar2 = 0, l1, l2;
        HashSet<Integer> pasadas = new HashSet<>();
        while(lugar1 == lugar2) {
            lugar1 = (int)(GeneticAlgorithm.rnd.nextDouble()*numCiudades);
            lugar2 = (int)(GeneticAlgorithm.rnd.nextDouble()*numCiudades);
        }
        l1 = Math.min(lugar1, lugar2);
        l2 = Math.max(lugar1, lugar2);
        lugar1 = l1;
        lugar2 = l2;
        for(int i = lugar1; i <= lugar2; i++) {
            pasadas.add(A.getGen(i));
            hijo.setGen(i, A.getGen(i));
        }
        LinkedList<Integer> faltantes = new LinkedList<>();
        for(int i=0; i<B.size(); i++) {
            if(!pasadas.contains(B.getGen(i)))
                faltantes.addLast(B.getGen(i));
        }
        for(int i=0; i<hijo.size(); i++) {
           if(hijo.getGen(i)==0)
               hijo.setGen(i, faltantes.pop());
        }
        
        
        return hijo;
    }
}
